#ifndef CONTROLLER_BUKU_H
#define CONTROLLER_BUKU_H

#include <iostream>
#include <iomanip>  // Untuk format tabel
#include "../data/buku.h"

using namespace std;

// Definisikan pohonBuku dan rootBuku sebagai pointer global bertipe treeBuku*
treeBuku* pohonBuku = nullptr;
treeBuku* rootBuku = nullptr;

// Prototipe fungsi
void insert_buku(Buku data);
void show_list_buku(treeBuku *root);
Buku find_id_buku(treeBuku **root, int id);
void insert_books();
void updateStatusBuku(treeBuku **root, int id);
Buku updateBukuStatus(Buku data);
void admin_interface();

void insert_buku(Buku data)
{
    treeBuku *newBook = new treeBuku;
    newBook->data = data;
    newBook->left = nullptr;
    newBook->right = nullptr;

    if (pohonBuku == nullptr)
    {
        pohonBuku = newBook;
        rootBuku = newBook;
    }
    else
    {
        treeBuku *current = pohonBuku;
        treeBuku *parent = nullptr;

        while (true)
        {
            parent = current;

            if (data.id < current->data.id)
            {
                current = current->left;

                if (current == nullptr)
                {
                    parent->left = newBook;
                    return;
                }
            }
            else
            {
                current = current->right;

                if (current == nullptr)
                {
                    parent->right = newBook;
                    return;
                }
            }
        }
    }
}

void show_list_buku(treeBuku *root)
{
    if (root != nullptr)
    {
        cout << setw(5) << root->data.id << " | "
             << setw(30) << root->data.judul << " | "
             << setw(30) << root->data.penulis << " | "
             << setw(30) << root->data.penerbit << " | "
             << setw(30) << root->data.tahun_terbit << " | "
             << setw(30) << root->data.deskripsi << " | "
             << setw(30) << root->data.harga << " | "
             << setw(5) << root->data.stock << " | "
             << setw(15) << root->data.status << " | "
             
        show_list_buku(root->left);
        show_list_buku(root->right);
    }
}

void display_table(treeBuku *root)
{
    cout << setw(5) << "ID" << " | "
         << setw(30) << "Judul" << " | "
         << setw(5) << "Penulis" << " | "
         << setw(5) << "Penerbit" << " | " 
         << setw(5) << "Tahun Terbit" << " | "
         << setw(15) << "Deskripsi" << " | "
         << setw(5) << "Harga" << " | "
         << setw(5) << "Stock" << " | "
         << setw(5) << "Status" << "\n";
    cout << string(60, '-') << "\n";
    show_list_buku(root);
}

Buku find_id_buku(treeBuku **root, int id)
{
    int level = 0;
    treeBuku *temp = *root;

    while (temp != nullptr)
    {
        level++;
        if (temp->data.id == id)
        {
            return temp->data;
        }
        else if (id < temp->data.id)
        {
            temp = temp->left;
        }
        else
        {
            temp = temp->right;
        }
    }

    cout << "Data tidak ditemukan" << endl;
    return {};
}

void insert_books()
{
    insert_buku(data_buku1);
    insert_buku(data_buku2);
    insert_buku(data_buku3);
    insert_buku(data_buku4);
    insert_buku(data_buku5);
    insert_buku(data_buku6);
    insert_buku(data_buku7);
    insert_buku(data_buku8);
    insert_buku(data_buku9);
    insert_buku(data_buku10);
    // Tambahkan buku lainnya sesuai kebutuhan
}

void updateStatusBuku(treeBuku **root, int id)
{
    treeBuku *temp = *root;

    while (temp != nullptr)
    {
        if (temp->data.id == id)
        {
            if (temp->data.stock > 0)
            {
                temp->data.stock--;
                if (temp->data.stock == 0)
                {
                    temp->data.status = "Tidak Tersedia";
                }
            }
            return;
        }
        else if (id < temp->data.id)
        {
            temp = temp->left;
        }
        else
        {
            temp = temp->right;
        }
    }
}

Buku updateBukuStatus(Buku data)
{
    treeBuku *temp = pohonBuku;
    while (temp != nullptr)
    {
        if (temp->data.id == data.id)
        {
            temp->data.status = data.status;
            temp->data.stock = data.stock;
            return temp->data;
        }
        else if (data.id < temp->data.id)
        {
            temp = temp->left;
        }
        else
        {
            temp = temp->right;
        }
    }

    return {};
}

void admin_interface()
{
    int choice;
    do
    {
        cout << "Antarmuka Admin\n";
        cout << "1. Tambah Buku\n";
        cout << "2. Tampilkan Daftar Buku\n";
        cout << "3. Perbarui Status Buku\n";
        cout << "4. Keluar\n";
        cout << "Masukkan pilihan Anda: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            Buku newBook;
            cout << "Masukkan ID buku: ";
            cin >> newBook.id;
            cout << "Masukkan judul buku: ";
            cin.ignore();  // Untuk mengabaikan karakter newline yang tersisa
            getline(cin, newBook.judul);
            cout << "Masukkan stok buku: ";
            cin >> newBook.stock;
            newBook.status = (newBook.stock > 0) ? "Tersedia" : "Tidak Tersedia";
            insert_buku(newBook);
            display_table(rootBuku); // Tampilkan tabel setelah penambahan
            break;
        }
        case 2:
        {
            display_table(rootBuku); // Tampilkan tabel
            break;
        }
        case 3:
        {
            int id;
            cout << "Masukkan ID buku untuk memperbarui status: ";
            cin >> id;
            updateStatusBuku(&rootBuku, id);
            display_table(rootBuku); // Tampilkan tabel setelah memperbarui status
            break;
        }
        case 4:
            cout << "Keluar dari Antarmuka Admin\n";
            break;
        default:
            cout << "Pilihan tidak valid. Silakan coba lagi.\n";
        }
    } while (choice != 4);
}

#endif
