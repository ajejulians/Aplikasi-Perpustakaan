#ifndef CEK_DENDA_H
#define CEK_DENDA_H

#include <string>

double cek_denda(const std::string &tanggal_terlambat, int hari_terlambat, double harga_denda);

#endif